package com.example;


import javax.servlet.http.HttpServletRequest;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;

@Controller
public class ServicesController {
	
	@RequestMapping("/")
	public String index(HttpServletRequest request, Model model) throws Exception {
		return "index";
	}
}
