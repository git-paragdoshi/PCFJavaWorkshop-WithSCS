package com.example;


import javax.servlet.http.HttpServletRequest;

import org.springframework.cloud.context.config.annotation.RefreshScope;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.beans.factory.annotation.Value;

@Controller
@RefreshScope
public class ServicesController {

	@Value("${greeting:Hi}")
	private String _greeting;

	
	@RequestMapping("/")
	public String index(HttpServletRequest request, Model model) throws Exception {
		model.addAttribute("greeting", _greeting);
		return "index";
	}
}
